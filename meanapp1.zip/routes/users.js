const express = require('express');
const router  = express.Router();
const User     = require('../model/user.js');
const passport = require('passport');
const jwt      = require('jsonwebtoken');
const config   = require('../config/database');

//Retriving Results from Server
router.get('/getUser',(req,res)=>{
    User.find((err,docs)=>{
        if(!err){
            res.send(docs);
        }
        else{
            console.log('Failed to fetch result'+JSON.stringify(err,undefined,2));
        }
    });
});

//Retriving Particular User
/*router.get('/:id',(req,res)=>{
    User.findById(req.params.id,(err,docs)=>{
        if(!err){
            res.send(docs);
        }
        else{
            res.json({success:false,msg:'Unable to receive particular user'});
        }
    });
});*/
//adding a newUser
router.post('/register',(req,res,next)=>{
  let newUser = new User({
      name:req.body.name,
      email:req.body.email,
      username:req.body.username,
      password:req.body.password
  });
    User.addUser(newUser, (err, user) => {
        if(err){
          res.json({success: false, msg:'Failed to register user'});
        } else {
          res.json({success: true, msg:'User registered'});
        }
      });
});


//passport-jwt authentication ,checks whether user types username and password are 
//in database which are stored with username as string and password hashed 
//first its get username and password form req.from 
//first, its check whether it has any error 
//second , if no user 
//success , then compare actual password with hash password 

router.post('/authenticate',(req,res,next)=>{
    
    const username = req.body.username;
    const password = req.body.password;

    User.getUserByUsername(username,(err,user)=>{
        if(err) throw err;
        if(!user){
            return res.json({success:false,msg:'User not found'});
        }
        User.comparePassword(password,user.password,(err,isMatch)=>{
            if(err) throw err;
            if(isMatch){
                const token = jwt.sign(user.toJSON(), config.secret,{
                    expiresIn: 604800
                });

                res.send({
                    success: true,
                    token:'Bearer '+token,
                    user:{
                        id:user._id,
                        name:user.name,
                        username:user.username,
                        email:user.email
                    }
                });
            }else{
                return res.json({success:false,msg:'Wrong password'});
            }
        })
    });
});


//protecting route 
//token in stored in cookie or session 
//unauthorized cannot access the application 
router.get('/profile',passport.authenticate('jwt',{session:false}),(req,res,next)=>{
    
    res.json({user: req.user});

});


module.exports = router;
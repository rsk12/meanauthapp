module.exports = {
    database : 'mongodb+srv://sai:sai@rsk-1usjo.mongodb.net/test?retryWrites=true&w=majority',
    secret: 'yoursecret',
}
